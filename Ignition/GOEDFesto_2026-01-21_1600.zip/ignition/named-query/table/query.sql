Create table measuring(
Bloknummer int,
Hoogte int,
Gewicht int)