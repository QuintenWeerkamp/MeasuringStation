def onStartup():
	if username == "550328":
		system.nav.
	system.nav.openwindow
	system.nav.openwindow 
else :
	system.nav.openwindow 
	system.nav.openwindow 
